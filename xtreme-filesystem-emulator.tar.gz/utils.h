#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *copyString(char *);
char *getString(char *, int );